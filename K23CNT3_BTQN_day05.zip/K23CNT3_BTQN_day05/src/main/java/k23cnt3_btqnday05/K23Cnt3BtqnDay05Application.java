package k23cnt3_btqnday05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K23Cnt3BtqnDay05Application {

	public static void main(String[] args) {
		SpringApplication.run(K23Cnt3BtqnDay05Application.class, args);
	}

}
