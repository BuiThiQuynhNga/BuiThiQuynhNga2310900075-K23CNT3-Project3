package k23cnt3_btqnday08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K23Cnt3BtqnDay8Application {

	public static void main(String[] args) {
		SpringApplication.run(K23Cnt3BtqnDay8Application.class, args);
	}

}
