package k23cnt3_btqn_day02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K23cnt3BtqnDay02Application {

	public static void main(String[] args) {
		SpringApplication.run(K23cnt3BtqnDay02Application.class, args);
	}

}
