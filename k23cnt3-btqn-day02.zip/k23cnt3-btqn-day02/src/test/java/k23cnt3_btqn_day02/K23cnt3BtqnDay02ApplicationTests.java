package k23cnt3_btqn_day02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K23cnt3BtqnDay02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
