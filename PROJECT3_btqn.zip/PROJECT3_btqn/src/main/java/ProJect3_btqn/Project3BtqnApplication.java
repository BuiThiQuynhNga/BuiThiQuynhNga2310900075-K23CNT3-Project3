package ProJect3_btqn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Project3BtqnApplication {

	public static void main(String[] args) {
		SpringApplication.run(Project3BtqnApplication.class, args);
	}

}
