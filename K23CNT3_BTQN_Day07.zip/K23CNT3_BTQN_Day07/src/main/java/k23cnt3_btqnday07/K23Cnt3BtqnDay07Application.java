package k23cnt3_btqnday07;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class K23Cnt3BtqnDay07Application {

	public static void main(String[] args) {
		SpringApplication.run(K23Cnt3BtqnDay07Application.class, args);
	}

}
