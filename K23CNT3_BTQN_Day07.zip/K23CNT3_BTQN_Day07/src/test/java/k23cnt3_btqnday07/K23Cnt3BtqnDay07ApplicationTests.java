package k23cnt3_btqnday07;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K23Cnt3BtqnDay07ApplicationTests {

	@Test
	void contextLoads() {
	}

}
